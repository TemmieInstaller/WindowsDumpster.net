﻿=== Kirby Cursor Set ===

By: Frangel ッ (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/kirby-dreamlan

Author's description:

 "Kirby Cursors, Sprites Kirby: Pesadilla en Dreamland"

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.